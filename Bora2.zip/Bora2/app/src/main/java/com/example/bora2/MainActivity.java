package com.example.bora2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import org.w3c.dom.Text;


public class MainActivity extends AppCompatActivity implements TextWatcher, View.OnClickListener, TextToSpeech.OnInitListener {

    EditText etValor1, etValor2;
    TextView tvResultado;
    double num1, num2, res;
    FloatingActionButton share, tocar;
    TextToSpeech ttsPlayer;

    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        etValor1 = (EditText) findViewById(R.id.et_valor1);
        etValor2 = (EditText) findViewById(R.id.et_valor2);
        tvResultado = (TextView) findViewById(R.id.tv_resultado);


        etValor1.addTextChangedListener(this);

        share = (FloatingActionButton) findViewById(R.id.btShare);
        share.setOnClickListener(this);
        tocar = (FloatingActionButton) findViewById(R.id.btToca);
        tocar.setOnClickListener(this);

        Intent checkTTSIntent = new Intent();
        checkTTSIntent.setAction(TextToSpeech.Engine.ACTION_CHECK_TTS_DATA);
        startActivityForResult(checkTTSIntent,1122);
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data){

        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==1122){
            if(resultCode== TextToSpeech.Engine.CHECK_VOICE_DATA_PASS){
                ttsPlayer = new TextToSpeech(this,this);

            } else {Intent installTTSIntent = new Intent();
            installTTSIntent.setAction(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA);
            startActivity(installTTSIntent);}

        }
    }



    @Override

    public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
    }

    @Override
    public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
    }

    @Override

    public void afterTextChanged(Editable s) {

        try {

            double res = Double.parseDouble(etValor1.getText().toString());
            double num1 = Double.parseDouble(etValor1.getText().toString());
            double num2 = Double.parseDouble(etValor2.getText().toString());

            res = (num2 / num1);

            DecimalFormat df = new DecimalFormat("#.00");

            tvResultado.setText("R$" + df.format(res));
        } catch (Exception e) {
            tvResultado.setText("R$ 0.00");
        }
    }


    @Override
    public void onClick(View view) {
        if (view==share){
        Intent intent = new Intent (Intent.ACTION_SEND);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_TEXT,"A conta dividida por pessoa deu "+tvResultado.getText().toString());
        startActivity(intent);
    }

        if (view==tocar){
            if (ttsPlayer!=null){
                ttsPlayer.speak("O valor por pessoa é de " +tvResultado.getText().toString()+ "reais",TextToSpeech.QUEUE_FLUSH, null, "ID1");
            }
        }
}

    @Override
    public void onInit(int initStatus) {
        if (initStatus==TextToSpeech.SUCCESS) {
            Toast.makeText(this, "TTS Ativado...",
                    Toast.LENGTH_LONG).show();
        } else if (initStatus==TextToSpeech.ERROR){
            Toast.makeText(this, "Sem TTS habilitado...",
            Toast.LENGTH_LONG).show();
        }
        }
    }


